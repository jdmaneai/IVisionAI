﻿using Microsoft.AspNetCore.Mvc;
using realQuickOrder.Data;
using realQuickOrder.Helpers;
using realQuickOrder.Models;
using System.Threading.Tasks;

namespace realQuickOrder.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly TransactionRepository _repository;
        private readonly AIHelper _aiHelper;

        public TransactionController(TransactionRepository repository, AIHelper aiHelper)
        {
            _repository = repository;
            _aiHelper = aiHelper;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessTransaction([FromBody] string inputText)
        {
            var transactionData = await _aiHelper.Test(inputText);

            if (transactionData == null)
                return BadRequest("Failed to extract transaction details.");

            var transaction = new Transaction
            {
                StockSymbol = transactionData.StockSymbol,
                Quantity = transactionData.Quantity,
                Account = transactionData.Account,
                TransactionType = transactionData.TransactionType
            };

            _repository.InsertTransaction(transaction);
            return Ok(new { message = "Transaction processed successfully!", transaction });
        }
    }
}
