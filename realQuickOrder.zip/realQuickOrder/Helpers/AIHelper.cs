﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace realQuickOrder.Helpers
{
    public class AIHelper
    {
        private readonly string _apiKey;
        private readonly string _endpoint;
        private readonly HttpClient _httpClient;

        public AIHelper(IConfiguration configuration)
        {
            _apiKey = configuration["OpenAI:ApiKey"];
            _endpoint = configuration["OpenAI:Endpoint"];
            _httpClient = new HttpClient();
        }

        public async Task<TransactionData> ExtractTransactionData(string inputText)
        {
            var requestBody = new
            {
                model = "gpt-4o",
                messages = new[]
                {
            new { role = "system", content = "Extract stock transaction details: StockSymbol, Quantity, Account, TransactionType (Buy/Sell)." },
            new { role = "user", content = inputText }
        },
                temperature = 0.3
            };

            var requestContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

            if (!_httpClient.DefaultRequestHeaders.Contains("Authorization"))
            {
                _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"Bearer {_apiKey}");
            }
            var apiUrl = $"{_endpoint}/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-01";
            var response = await _httpClient.PostAsync($"{_endpoint}/gpt-4o/chat/completions", requestContent);
            var responseBody = await response.Content.ReadAsStringAsync();

            var extractedData = JsonSerializer.Deserialize<AIResponse>(responseBody);
            return extractedData?.Choices?[0]?.Message?.Content is not null
                ? JsonSerializer.Deserialize<TransactionData>(extractedData.Choices[0].Message.Content)
                : null;
        }

        public async Task<TransactionData?> Test(string input)
        {
            var endpoint = "https://endPoint.openai.azure.com"; // Azure OpenAI endpoint
            var apiKey = "bigkey"; // Replace with your actual API key
            var deploymentName = "gpt-4o"; // actual deployment name

            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("api-key", apiKey);

            var requestBody = new
            {
                messages = new[]
                {
                new { role = "system", content = "Extract stock transaction details and return only JSON with the following structure:\n { \"StockSymbol\": \"ABC\", \"Quantity\": 50, \"Account\": \"XYZ\", \"TransactionType\": \"Buy\" }" },
                new { role = "user", content = input }
            },
                max_tokens = 200
            };

            var jsonContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

            var apiUrl = $"{endpoint}/openai/deployments/{deploymentName}/chat/completions?api-version=2024-02-01";
            var response = await httpClient.PostAsync(apiUrl, jsonContent);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode) return null;

            var result = await response.Content.ReadAsStringAsync();
            var parsedData = JsonSerializer.Deserialize<TransactionData>(result);

            // Deserialize the OpenAI response
            using var doc = JsonDocument.Parse(responseBody);
            var messageContent = doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString();

            // Convert the extracted string into a proper JSON object
            var employee = JsonSerializer.Deserialize<TransactionData>(messageContent);

            Console.WriteLine($"Extracted Employee: {employee.Quantity} {employee.Account}");

            return employee;
            // Convert AI response to Employee model
            //return new Employee
            //{
            //    firstname = parsedData?.ExtractedFirstName ?? "Unknown",
            //    LastName = parsedData?.Extractedlastname ?? "Lastname",
            //    //Department = parsedData?.ExtractedDepartment ?? "Unknown"
            //};
        }

    }

    public class AIResponse
    {
        public Choice[] Choices { get; set; }
    }

    public class Choice
    {
        public Message Message { get; set; }
    }

    public class Message
    {
        public string Content { get; set; }
    }

    public class TransactionData
    {
        public string StockSymbol { get; set; }
        public int Quantity { get; set; }
        public string Account { get; set; }
        public string TransactionType { get; set; }
    }
}
