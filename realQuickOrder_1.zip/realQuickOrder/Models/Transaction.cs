﻿namespace realQuickOrder.Models
{
    public class Transaction
    {
        public int Id { get; set; }
        public string StockSymbol { get; set; }
        public int Quantity { get; set; }
        public string Account { get; set; }
        public string TransactionType { get; set; } // Buy/Sell
        public string OrderType { get; set; } // Market/LIMIT
        public DateTime Timestamp { get; set; }
    }
}
