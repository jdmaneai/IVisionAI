﻿using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using realQuickOrder.Models;

namespace realQuickOrder.Data
{
    public class TransactionRepository
    {
        private readonly string _connectionString;

        public TransactionRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public void InsertTransaction(Transaction transaction)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Transactions (StockSymbol, Quantity, Account, TransactionType, Timestamp) VALUES (@StockSymbol, @Quantity, @Account, @TransactionType, @Timestamp)", conn))
                {
                    cmd.Parameters.AddWithValue("@StockSymbol", transaction.StockSymbol);
                    cmd.Parameters.AddWithValue("@Quantity", transaction.Quantity);
                    cmd.Parameters.AddWithValue("@Account", transaction.Account);
                    cmd.Parameters.AddWithValue("@TransactionType", transaction.TransactionType);
                    cmd.Parameters.AddWithValue("@Timestamp", DateTime.Now);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
